import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class PrimeNumberMethodTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	public void primeNumberTestPositive() {
        assertTrue(PrimeNumberMethod.isPrime(2));
        assertTrue(PrimeNumberMethod.isPrime(3));
        assertTrue(PrimeNumberMethod.isPrime(5));
        assertTrue(PrimeNumberMethod.isPrime(7));
    }
	@Test			
	public void primeNumberTestNegative() {		
		assertFalse(PrimeNumberMethod.isPrime(4));
	    assertFalse(PrimeNumberMethod.isPrime(9));
	    assertFalse(PrimeNumberMethod.isPrime(10));
	    assertFalse(PrimeNumberMethod.isPrime(15));	    	
	}

}
