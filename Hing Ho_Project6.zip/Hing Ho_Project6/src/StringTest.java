import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Before;

public class StringTest {
   
	@Before
	public void setUp() throws Exception{
		
	}
	
	@Test	
	public void lengthTest() {
        assertEquals(0, "".length());
        assertEquals(1, "B".length());
        assertEquals(2, "Be".length());
        assertEquals(3, "Bei".length());
        assertEquals(4, "Beij".length());
        assertEquals(5, "Beiji".length());
        assertEquals(6, "Beijin".length());
        assertEquals(7, "Beijing".length());
    }

    @Test
    public void charAtTest() {
        assertEquals('B', "Beijing".charAt(0));
        assertEquals('e', "Beijing".charAt(1));
        assertEquals('i', "Beijing".charAt(4));
        assertEquals('g', "Beijing".charAt(6));
    }

    @Test
    public void subStringTest() {
        assertEquals("I love", "I love Beijing".substring(0, 6));
        assertEquals("Beijing", "I love Beijing".substring(7));
        assertEquals("love", "I love Beijing".substring(2, 6));
        assertEquals("I love Beijing", "I love Beijing".substring(0));
    }

    @Test
    public void indexOfTest() {
        assertEquals(5, "China Beijing".indexOf(' '));
        assertEquals(1, "China Beijing".indexOf('h'));
        assertEquals(0, "China Beijing".indexOf('C'));
        assertEquals(6, "China Beijing".indexOf('B'));
    }
}